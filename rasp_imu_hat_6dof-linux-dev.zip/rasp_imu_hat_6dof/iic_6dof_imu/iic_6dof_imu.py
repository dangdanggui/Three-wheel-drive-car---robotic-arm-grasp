#!/usr/bin/env python
# -*- coding: UTF-8 -*-

# Copyright: 2016-2021 https://www.corvin.cn ROS小课堂
# Description: 从IIC接口中读取6DOF IMU模块的三轴加速度、角度、四元数，
#    然后组装成ROS中的IMU消息格式，发布到/imu_data话题中，这样有需要的
#    节点可以直接订阅该话题即可获取到imu当前的数据.
# Author: corvin
# History:
#    20211122:Initial this file.
import math
import time

from iic_6dof_imu_data import MyIMU


degrees2rad = math.pi/180.0
yaw = 0.0

seq = 0
accel_factor = 9.806  #sensor accel g convert to m/s^2.

imu_iic_bus = 1
imu_iic_addr = 0x50
myIMU = MyIMU(imu_iic_bus, imu_iic_addr)

print("Now 6DOF IMU Module is working ...")
while True:
    myIMU.get_YPRAG()

    #rospy.loginfo("yaw:%f pitch:%f roll:%f", myIMU.raw_yaw,
    #              myIMU.raw_pitch, myIMU.raw_roll)
    yaw_deg = float(myIMU.raw_yaw)
    if yaw_deg >= 180.0:
        yaw_deg -= 360.0

    #rospy.loginfo("yaw_deg: %f", yaw_deg)
    yaw   = yaw_deg*degrees2rad
    pitch = float(myIMU.raw_pitch)*degrees2rad
    roll  = float(myIMU.raw_roll)*degrees2rad

    print("roll: ", yaw, "pitch: ", pitch, "yaw: ", yaw)
    myIMU.get_quatern()
    print("q_x: ", myIMU.raw_q1, "q_y: ", myIMU.raw_q2, "q_z: ", myIMU.raw_q3, "q_w: ", myIMU.raw_q0)
    print("a_v_x: ", float(myIMU.raw_gx)*degrees2rad, "a_v_y: ", float(myIMU.raw_gy)*degrees2rad, "a_v_z: ", float(myIMU.raw_gz)*degrees2rad)
    print("l_acc_x: ", -float(myIMU.raw_ax)*accel_factor ,"l_acc_y: ", -float(myIMU.raw_ay)*accel_factor ,"l_acc_z: ", -float(myIMU.raw_az)*accel_factor)
    time.sleep(0.1)