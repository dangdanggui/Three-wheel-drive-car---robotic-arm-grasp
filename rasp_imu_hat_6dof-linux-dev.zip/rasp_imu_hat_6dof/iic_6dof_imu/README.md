#### 下载代码
```
git clone -b linux-dev https://code.corvin.cn:3000/corvin_zhang/rasp_imu_hat_6dof.git
```

#### 运行
```
python iic_6dof_imu.py
```
