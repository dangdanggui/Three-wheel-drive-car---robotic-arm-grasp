/*
 * @Copyright(C): 2016-2021 ROS小课堂 www.corvin.cn
 * @Author: adam_zhuo
 * @Date: 2021-11-26 10:13:03
 * @Description: file content
 * @History: 20210429:-adam_zhuo
 */
/*******************************************************
 * Copyright:2016-2021 www.corvin.cn ROS小课堂
 * Description:使用串口操作读取imu模块的代码头文件.
 * Author: corvin
 * History:
 *   20211122:init this file.
 *******************************************************/
#ifndef _IMU_DATA_H_
#define _IMU_DATA_H_

#include<stdio.h>
#include<stdlib.h>
#include<fcntl.h>
#include<unistd.h>
#include<termios.h>
#include<string.h>
#include<sys/time.h>
#include<sys/types.h>
#include<iostream>
#include<sstream>
#include <iomanip>

void init_keyboard(void);
void close_keyboard(void);
int kbhit(void);
int initSerialPort(const char* path);

int getImuData(void);
int closeSerialPort(void);

float getAcc(int flag);
float getAngular(int flag);
float getAngle(int flag);
float getQuat(int flag);

int makeYawZero(void);
int updateIICAddr(std::string input);
void show_imu_data(void);
#endif