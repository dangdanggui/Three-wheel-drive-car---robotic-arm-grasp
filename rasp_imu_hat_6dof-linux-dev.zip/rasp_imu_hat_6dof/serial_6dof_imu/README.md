#### 下载代码
```
git clone -b linux-dev https://code.corvin.cn:3000/corvin_zhang/rasp_imu_hat_6dof.git
```

#### 编译
```
mkdir build
cd build
cmkae ..
make 
```
