﻿/*****************************************************************
 * Copyright:2016-2021 www.corvin.cn ROS小课堂
 * Description:使用串口来读取IMU的数据.
 * Author: adam_zhuo
 * History:
 *   20211124: init this file.
*****************************************************************/
#include "../include/imu_data.h"

using namespace std;

void show_direction() {
    cout << "----------------------------------------" << endl;
    cout << "----------------------------------------" << endl;
    cout << "                                        " << endl;
    cout << "                                        " << endl;
    cout << "------------  0命令, 退出  -------------" << endl;
    cout << "------  1命令，IMU模块yaw角归0  --------" << endl;
    cout << "------  2命令，修改I2C地址      --------" << endl;
    cout << "------  3命令，显示IMU模块数据  --------" << endl;
    cout << "                                        " << endl;
    cout << "                                        " << endl;
    cout << "----------------------------------------" << endl;
    cout << "----------------------------------------" << endl;
}

int main(int argc, char** argv)
{
    
    string imu_dev = "com1";
    int order = 0;
    string input;

    while (true)
    {
        cout << "输入串口号（例如：/dev/ttyUSB0）：" << endl;
        cin >> imu_dev;
        
        int ret = initSerialPort(imu_dev.c_str());
        if (ret != 1) //通过串口连接IMU模块失败
        {
            cout << endl << "打开6自由度IMU模块串口失败 ！！！" << endl << endl;
            closeSerialPort();
            continue;
        }
        cout << endl << "打开6自由度IMU模块串口成功 !" << endl << endl;
        break;
    }

    while (true)
    {
        show_direction();
        cout << "输入指令：" << endl;
        cin >> order;
        if (order < 0 || order > 3)
        {
            cout << endl <<"输入正确的指令！！！" << endl << endl;
            continue;
        }
        switch (order)
        {
        case 0:
            closeSerialPort(); //关闭与IMU模块的串口连接
            return 0;
            break;
        case 1:
            makeYawZero();  //yaw角归0
            break;
        case 2:
            cout << "输入I2C地址（0x00-0x7F）：" << endl;
            cin >> input;
            updateIICAddr(input);
            break;
        case 3:
            show_imu_data();  //显示imu数据
            break;
        default:
            break;
        }

    }

    closeSerialPort(); //关闭与IMU模块的串口连接
    return 0;
}