# rasp_imu_hat_6dof

为树莓派IMU扩展板创建的ROS代码仓库，直接将该软件包源码放在ROS工作区src目录下即可。然后使用catkin_make就可以进行编译了。完整的下载命令如下:  
`git clone https://code.corvin.cn:3000/corvin_zhang/rasp_imu_hat_6dof.git`  

----
## 使用串口发布IMU数据
当编译完成后可以使用如下命令启动发布imu数据:  
`roslaunch serial_imu_hat_6dof serial_imu_hat.launch`  

当启动上述命令后,可以在ROS中查看到如下话题和服务可以调用:  
* 发布imu数据的话题名: /imu_data
* 发布imu模块温度的话题名: /imu_temp
* 发布yaw角度的话题名: /yaw_data
* 可将yaw角度归零的话题名: /yaw_zero_topic
* 可将yaw角度归零的服务名: /yaw_zero_service
* 可修改串口波特率的服务: /baud_update_service
* 控制D0,D1,D2,D3输出数字高低电平的服务: /pin_outHL_service  
* 可得到当前yaw角度的服务: /imu_node/GetYawData  
对于以上这些话题名和服务名,都可以在serial_imu_hat_6dof/cfg/param.yaml配置文件中进行修改.  

1. 如果想使用话题方式,将yaw角度归零,那就可以执行如下命令:  
`rostopic pub -1 /yaw_zero_topic std_msgs/Empty "{}"`  

2. 如果想使用服务调用方式,将yaw角度归零,那执行如下命令:  
`rosservice call /yaw_zero_service "{}"`  

3. 如果想修改串口通信的波特率,那就可以执行如下命令:  
`rosservice call /baud_update_service "index: 1"`  
这里需要注意index后面的数字,１表示更新波特率为9600,2表示为57600,3表示115200,
当更新完波特率后,需要修改本地配置文件中串口波特率为新的,否则会无法正常获取imu数据.  

4. 如果需要控制D0引脚输出高电平,那就可以使用如下命令:  
rosservice call /pin_outHL_service "D0: 1  
D1: 0  
D2: 0  
D3: 0"  
这里可以看到D0后面的数字为1,那就表明D0引脚输出高电平.若想修改其他引脚的高低电平状态,那就修改D0,D1,D2,D3后面的对应数字即可.  

5. 如果想通过服务调用方式来获取到当前的yaw角度信息,可在终端中执行如下命令:  
`rosservice call /imu_node/GetYawData`  
当然这些不仅可以在终端中执行命令获取到yaw数据,还可以在代码中编写服务的客户端程序,请求字段为空,就可以在response字段中获取到当前yaw角度.  

----
## 使用IIC发布IMU数据
`roslaunch rasp_imu_hat_6dof imu_data_pub.launch`  

----
## 在Rviz中显示查看IMU效果
`roslaunch rasp_imu_hat_6dof imu_rviz_display.launch`  

