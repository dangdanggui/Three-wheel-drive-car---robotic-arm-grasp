/*******************************************************
 * Copyright:2016-2021 www.corvin.cn ROS小课堂
 * Description:使用串口操作读取imu模块的代码头文件.
 * Author: corvin
 * History:
 *   20210318:init this file.
 *   20210319:增加修改串口通信波特率的函数.
 *   20210321:增加控制IMU引脚数字高低电平的函数.
 *******************************************************/
#ifndef _IMU_DATA_H_
#define _IMU_DATA_H_

int initSerialPort(const char* path, const int baud);

int getImuData(void);
int closeSerialPort(void);

float getAcc(int flag);
float getAngular(int flag);
float getAngle(int flag);
float getQuat(int flag);

int makeYawZero(void);
int setIMUBaudRate(const int flag);
int setIMUPinOutHL(const int d0,const int d1,const int d2,const int d3);
#endif
